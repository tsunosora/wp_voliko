//&lt;![CDATA[
    jQuery(document).ready(function($) {
        jQuery("#bottom-testimonial-section .sow-testimonials").addClass("owl-carousel");
        jQuery("#bottom-testimonial-section .sow-testimonials").owlCarousel( {
            items:1,
            pagination: true
        } );

   var checkRun = true;
       var checkWidths = $(window).width();
       
   function inViews(){    	
       var homeoutcap = $('#home-content-out-cap');        
        
       if(homeoutcap.length){
           var bottom_of_object = $('#home-content-out-cap').offset().top;
           var bottom_of_window = $(window).scrollTop() + $(window).height();
           if((bottom_of_window > bottom_of_object) && (checkWidths > 767)){
               return true;
           }

       }else{
           return false;
       }
   };
   
   function inView(){  
       var b = inViews();
       if(b == true && checkRun == true){
           checkRun = false;
           $('.block-mydoughnut').each(function(index, value){
               $this = $(this);
               var dataPercent    = $this.attr('data-percent');
               var dataColor      = $this.attr('data-color');

               dataPercent = typeof dataPercent != 'undefined' && $.isNumeric(dataPercent) ? dataPercent : 90;
               dataColor   = typeof dataColor != 'undefined' ? dataColor : '#fd5b4e';

               if(typeof dataPercent == 'undefined') {
                   dataPercent = 90;
                   dataColor   = '#fd5b4e';
               }

               var doughnutData = [
                   {value: parseInt(dataPercent), color: dataColor},
                   {value: parseInt(100 - dataPercent), color: "rgba(0,0,0,0)"}
               ];
               
               var doughnutElementID = index != 0 ? '#myDoughnut' + (index+1) : '#myDoughnut';

               $(doughnutElementID).doughnutit({
                   dnData: doughnutData,
                   dnSize: 187, 
                   dnInnerCutout: 90,
                   dnAnimation: true,
                   dnAnimationSteps: 60,
                   dnAnimationEasing: 'linear',
                   dnStroke: false,
                   dnShowText: true,
                   dnFontSize: '24px',
                   dnFontColor: dataColor,
                   dnText: dataPercent + '%', 
                   dnFontOffset:20,
                   dnStartAngle: 90,
                   dnCounterClockwise: false, 
               });// End Doughnut
           });

           b = false;  
       }
   }; 
   $(window).on('scroll', function() { 
       jQuery('#home-content-out-cap').each(function(){
           inView();	
       });
      
   });
   
   if(jQuery().matchHeight) {
       $('.shortcodes-sticky-product li .product-content-top').matchHeight({
           byRow: true,
           property: 'height',
           target: null,
           remove: false
       });
   }

});
//]]&gt;