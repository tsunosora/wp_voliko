jQuery(document).ready(function($) {
	jQuery('#number-box .widget-title').each(function(){
		jQuery("#number-box .widget-title").lettering();
	});   
});
